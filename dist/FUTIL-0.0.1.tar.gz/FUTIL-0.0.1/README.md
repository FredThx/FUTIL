FUTIL Lib - Une librairie des utilitaires de FredThx
========================================================================

Utilitaires

	- my_logging : pour utiliser les logs facilement
		Exemple d'usage :
			
		>>>from FUTIL.mylogging import *
		>>>my_logging(console_level = DEBUG, logfile_level = INFO)
		>>>
		>>>logging.debug('Hello')
	
	
Installation :
	sudo python setup.py install


	